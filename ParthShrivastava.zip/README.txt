
README: CSCI 585 : Database Systems
===============================================

NAME        : PARTH SHRIVASTAVA
USCUserName : parthshr
USC ID      : 1824596991
EMAIL       : parthshr@usc.edu


About the assignment
--------------------

I have used Lucidchart (browser-based) as my tooling diagram to draw craw foot notation for ERD.
I have made the assumption that for one project, there can only be one professor. However, the same professor can supervise multiple projects.



If you have any questions, please feel free to contact me over email.


